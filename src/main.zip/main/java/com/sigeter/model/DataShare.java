package com.sigeter.model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class DataShare {
    public static ObservableList<DetailGempa> catatan = FXCollections.observableArrayList();
}
