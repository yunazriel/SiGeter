package com.sigeter.controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

public class HomeController implements Initializable {
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    
    
}
